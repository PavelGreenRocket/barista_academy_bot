// src/bot/attest.js
// Академия: настройка элементов аттестации (админ) + просмотр (пользователь)

const pool = require("../db/pool");
const { Markup } = require("telegraf");
const { deliver } = require("../utils/renderHelpers");

// состояния
// key: telegram_id, value: { step, itemId?, tempTitle?, tempType? }
const attestStates = new Map();

function setState(userId, state) {
  attestStates.set(userId, state);
}
function clearState(userId) {
  attestStates.delete(userId);
}
function getState(userId) {
  return attestStates.get(userId);
}
function isAdmin(user) {
  return user && user.role === "admin";
}

async function ensureDefaultAttestationItems() {
  const defaults = [
    { title: "📖 техкарта", order_index: 1 },
    { title: "📘 теория база", order_index: 2 },
    { title: "📕 теория продвинутый", order_index: 3 },
  ];

  for (const d of defaults) {
    // eslint-disable-next-line no-await-in-loop
    await pool.query(
      `INSERT INTO attestation_items (title, order_index, is_active, is_default, item_type)
       SELECT $1, $2, TRUE, TRUE, 'normal'
       WHERE NOT EXISTS (
         SELECT 1 FROM attestation_items WHERE COALESCE(is_default,FALSE)=TRUE AND order_index=$2
       )`,
      [d.title, d.order_index]
    );

    // eslint-disable-next-line no-await-in-loop
    await pool.query(
      `UPDATE attestation_items
       SET title=$1, item_type='normal'
       WHERE COALESCE(is_default,FALSE)=TRUE AND order_index=$2`,
      [d.title, d.order_index]
    );
  }
}

function typeLabel(t) {
  if (t === "photo") return "фото";
  if (t === "video") return "видео";
  return "обычный";
}

async function showUserAttestMenu(ctx, userId) {
  const res = await pool.query(
    `SELECT ai.id, ai.title, ai.description,
            COALESCE(ai.item_type,'normal') AS item_type,
            uas.status
     FROM attestation_items ai
     LEFT JOIN user_attestation_status uas
       ON uas.item_id = ai.id AND uas.user_id = $1
     WHERE ai.is_active = TRUE
     ORDER BY ai.order_index, ai.id`,
    [userId]
  );

  if (!res.rows.length) {
    const keyboard = Markup.inlineKeyboard([
      [Markup.button.callback("🔙 В главное меню", "back_main")],
    ]);

    await deliver(
      ctx,
      {
        text: 'Раздел "Аттестация" пока пуст. Админ ещё не добавил элементы аттестации.',
        extra: keyboard,
      },
      { edit: true }
    );
    return;
  }

  let text = "✅ Аттестация\n\n";
  const buttons = [];

  for (const row of res.rows) {
    let icon = "⚪";
    if (row.status === "passed") icon = "✅";
    text += `${icon} ${row.title}\n`;

    const title = (row.title || "").trim().toLowerCase();
    if (title === "техкарта" || title === "техкарты" || title.includes("техкарта")) {
      buttons.push([
        Markup.button.url("Техкарта", "https://t.me/TexKarGreenRocketbot"),
      ]);
    } else {
      buttons.push([Markup.button.callback(row.title, `user_attest_item_${row.id}`)]);
    }
  }

  buttons.push([Markup.button.callback("🔙", "back_main")]);

  await deliver(ctx, { text, extra: Markup.inlineKeyboard(buttons) }, { edit: true });
}

async function showUserAttestItem(ctx, userId, itemId) {
  const res = await pool.query(
    `SELECT ai.id, ai.title, ai.description,
            COALESCE(ai.item_type,'normal') AS item_type,
            uas.status
     FROM attestation_items ai
     LEFT JOIN user_attestation_status uas
       ON uas.item_id = ai.id AND uas.user_id = $1
     WHERE ai.id = $2`,
    [userId, itemId]
  );

  if (!res.rows.length) {
    await ctx.reply("Элемент аттестации не найден.");
    return;
  }

  const row = res.rows[0];
  let icon = "⚪";
  let statusText = "Ещё не сдано.";
  if (row.status === "passed") {
    icon = "✅";
    statusText = "Сдано ✅";
  }

  let text = `✅ Элемент аттестации\n\n${icon} ${row.title}\n\n${statusText}`;

  if (row.description) {
    text += `\n\nОписание:\n${row.description}`;
  }

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback("⬅ Назад к списку", "user_attest")],
    [Markup.button.callback("🔙 В главное меню", "back_main")],
  ]);

  await deliver(ctx, { text, extra: keyboard }, { edit: true });
}

// ----------------- АДМИНСКАЯ ЧАСТЬ -----------------

async function showAdminAttestMenu(ctx) {
  await ensureDefaultAttestationItems();

  const res = await pool.query(
    `SELECT id, title, order_index, is_active, COALESCE(is_default,FALSE) AS is_default
     FROM attestation_items
     ORDER BY order_index, id`
  );

  let text = "✅ Элементы аттестации:\n\n";
  const buttons = [];

  for (const row of res.rows) {
    const icon = row.is_active ? "✅" : "🚫";
    text += `${icon} [${row.order_index}] ${row.title}\n`;
    buttons.push([
      Markup.button.callback(`${icon} ${row.title}`, `admin_attest_item_${row.id}`),
    ]);
  }

  // добавлять можно только кастомные (после дефолтных)
  buttons.push([Markup.button.callback("➕ Новый элемент", "admin_attest_new")]);
  buttons.push([Markup.button.callback("🔙 В админ-панель", "admin_menu")]);

  await deliver(ctx, { text, extra: Markup.inlineKeyboard(buttons) }, { edit: true });
}

async function getAdminItem(itemId) {
  const res = await pool.query(
    `SELECT id, title, description, is_active, order_index,
            COALESCE(is_default,FALSE) AS is_default,
            COALESCE(item_type,'normal') AS item_type,
            example_file_id, example_file_type
     FROM attestation_items WHERE id=$1`,
    [itemId]
  );
  return res.rows[0] || null;
}

async function showAdminAttestItem(ctx, itemId) {
  const row = await getAdminItem(itemId);
  if (!row) {
    await ctx.reply("Элемент аттестации не найден.");
    return;
  }

  const statusText = row.is_active ? "Активен ✅" : "Скрыт 🚫";

  let text =
    `✅ Элемент аттестации\n\n` +
    `Название: ${row.title}\n` +
    `Статус: ${statusText}`;

  if (!row.is_default) {
    text += `\nТип: ${typeLabel(row.item_type)}`;
    if (row.description) text += `\n\nОписание:\n${row.description}`;
  }

  const kb = [];

  if (row.is_default) {
    kb.push([Markup.button.callback("👁 Вкл/Выкл", `admin_attest_toggle_${row.id}`)]);
    kb.push([Markup.button.callback("🔙 К списку", "admin_attest_menu")]);
  } else {
    kb.push([Markup.button.callback("✏ Название", `admin_attest_rename_${row.id}`)]);
    kb.push([Markup.button.callback("📝 Описание", `admin_attest_desc_${row.id}`)]);
    kb.push([Markup.button.callback("🔘 Тип", `admin_attest_type_${row.id}`)]);

    if (row.item_type === "photo") {
      kb.push([Markup.button.callback("🖼 пример фото", `admin_attest_example_${row.id}`)]);
    }
    if (row.item_type === "video") {
      kb.push([Markup.button.callback("🎬 пример видео", `admin_attest_example_${row.id}`)]);
    }

    kb.push([Markup.button.callback("👁 Вкл/Выкл", `admin_attest_toggle_${row.id}`)]);
    kb.push([Markup.button.callback("🗑 Удалить", `admin_attest_delete_${row.id}`)]);
    kb.push([Markup.button.callback("🔙 К списку", "admin_attest_menu")]);
  }

  await deliver(ctx, { text, extra: Markup.inlineKeyboard(kb) }, { edit: true });
}

async function showTypePicker(ctx, itemId, backAction) {
  const kb = Markup.inlineKeyboard([
    [
      Markup.button.callback("обычный", `admin_attest_type_set_${itemId}_normal`),
      Markup.button.callback("фото", `admin_attest_type_set_${itemId}_photo`),
      Markup.button.callback("видео", `admin_attest_type_set_${itemId}_video`),
    ],
    [Markup.button.callback("⬅️ Назад", backAction)],
  ]);

  await deliver(ctx, { text: "Выбери тип элемента:", extra: kb }, { edit: true });
}

// ----------------- РЕГИСТРАЦИЯ -----------------

function registerAttest(bot, ensureUser, logError) {
  // --- пользовательская часть ---
  bot.action("user_attest", async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!user) return;
      clearState(ctx.from.id);
      await showUserAttestMenu(ctx, user.id);
    } catch (err) {
      logError("user_attest", err);
      await ctx.reply("Не удалось открыть аттестацию.");
    }
  });

  bot.command("attest", async (ctx) => {
    try {
      const user = await ensureUser(ctx);
      if (!user) return;
      clearState(ctx.from.id);
      await showUserAttestMenu(ctx, user.id);
    } catch (err) {
      logError("/attest", err);
      await ctx.reply("Не удалось открыть аттестацию.");
    }
  });

  bot.action(/user_attest_item_(\d+)/, async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!user) return;
      const itemId = parseInt(ctx.match[1], 10);
      await showUserAttestItem(ctx, user.id, itemId);
    } catch (err) {
      logError("user_attest_item_x", err);
    }
  });

  // --- админская часть ---
  bot.action("admin_attest_menu", async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!isAdmin(user)) return;
      clearState(ctx.from.id);
      await showAdminAttestMenu(ctx);
    } catch (err) {
      logError("admin_attest_menu", err);
    }
  });

  bot.action("admin_attest_new", async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!isAdmin(user)) return;

      setState(ctx.from.id, { step: "new_title" });

      const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback("🔙 К списку", "admin_attest_menu")],
      ]);

      await deliver(
        ctx,
        { text: "✏ Введи название нового элемента аттестации одним сообщением:", extra: keyboard },
        { edit: true }
      );
    } catch (err) {
      logError("admin_attest_new", err);
    }
  });

  bot.action(/admin_attest_item_(\d+)/, async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!isAdmin(user)) return;
      clearState(ctx.from.id);
      const itemId = parseInt(ctx.match[1], 10);
      await showAdminAttestItem(ctx, itemId);
    } catch (err) {
      logError("admin_attest_item_x", err);
    }
  });

  bot.action(/admin_attest_rename_(\d+)/, async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!isAdmin(user)) return;

      const itemId = parseInt(ctx.match[1], 10);
      const row = await getAdminItem(itemId);
      if (row && row.is_default) return; // дефолт не переименовываем

      setState(ctx.from.id, { step: "rename_title", itemId });

      const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback("🔙 Назад", `admin_attest_item_${itemId}`)],
      ]);

      await deliver(ctx, { text: "✏ Введи новое название элемента:", extra: keyboard }, { edit: true });
    } catch (err) {
      logError("admin_attest_rename_x", err);
    }
  });

  bot.action(/admin_attest_desc_(\d+)/, async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!isAdmin(user)) return;

      const itemId = parseInt(ctx.match[1], 10);
      const row = await getAdminItem(itemId);
      if (row && row.is_default) return; // дефолт без описания

      setState(ctx.from.id, { step: "edit_desc", itemId });

      const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback("🔙 Назад", `admin_attest_item_${itemId}`)],
      ]);

      await deliver(
        ctx,
        {
          text:
            "📝 Отправь текст описания одним сообщением.\n" +
            "Старое описание будет перезаписано.",
          extra: keyboard,
        },
        { edit: true }
      );
    } catch (err) {
      logError("admin_attest_desc_x", err);
    }
  });

  bot.action(/admin_attest_type_(\d+)/, async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!isAdmin(user)) return;

      const itemId = parseInt(ctx.match[1], 10);
      const row = await getAdminItem(itemId);
      if (row && row.is_default) return;

      clearState(ctx.from.id);
      await showTypePicker(ctx, itemId, `admin_attest_item_${itemId}`);
    } catch (err) {
      logError("admin_attest_type_x", err);
    }
  });

  bot.action(/admin_attest_type_set_(\d+)_(normal|photo|video)/, async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!isAdmin(user)) return;

      const itemId = parseInt(ctx.match[1], 10);
      const t = ctx.match[2] === "normal" ? "normal" : ctx.match[2];

      await pool.query(`UPDATE attestation_items SET item_type=$2 WHERE id=$1`, [itemId, t]);

      // если сменили на normal — убираем пример
      if (t === "normal") {
        await pool.query(
          `UPDATE attestation_items SET example_file_id=NULL, example_file_type=NULL WHERE id=$1`,
          [itemId]
        );
      }

      await showAdminAttestItem(ctx, itemId);
    } catch (err) {
      logError("admin_attest_type_set_x", err);
    }
  });

  bot.action(/admin_attest_example_(\d+)/, async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!isAdmin(user)) return;

      const itemId = parseInt(ctx.match[1], 10);
      const row = await getAdminItem(itemId);
      if (!row || row.is_default) return;

      const kindLabel = row.item_type === "video" ? "видео" : "фото";

      setState(ctx.from.id, { step: "await_example", itemId, expected: row.item_type });

      const keyboard = Markup.inlineKeyboard([
        [Markup.button.callback("⬅️ Назад", `admin_attest_item_${itemId}`)],
      ]);

      await deliver(
        ctx,
        {
          text:
            `Отправь пример ${kindLabel} одним сообщением.\n` +
            `Или отправь "-" чтобы убрать пример.`,
          extra: keyboard,
        },
        { edit: true }
      );
    } catch (err) {
      logError("admin_attest_example_x", err);
    }
  });

  bot.action(/admin_attest_toggle_(\d+)/, async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!isAdmin(user)) return;

      const itemId = parseInt(ctx.match[1], 10);
      await pool.query(`UPDATE attestation_items SET is_active = NOT is_active WHERE id=$1`, [itemId]);
      await showAdminAttestItem(ctx, itemId);
    } catch (err) {
      logError("admin_attest_toggle_x", err);
    }
  });

  bot.action(/admin_attest_delete_(\d+)/, async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!isAdmin(user)) return;

      const itemId = parseInt(ctx.match[1], 10);
      const row = await getAdminItem(itemId);
      if (row && row.is_default) {
        await ctx.answerCbQuery("Нельзя удалить элемент по умолчанию.").catch(() => {});
        return;
      }

      await pool.query("DELETE FROM attestation_items WHERE id=$1", [itemId]);
      clearState(ctx.from.id);
      await showAdminAttestMenu(ctx);
    } catch (err) {
      logError("admin_attest_delete_x", err);
    }
  });

  // ---- обработка текста для админа (создание/переименование/описание/пример удалить) ----
  bot.on("text", async (ctx, next) => {
    const user = await ensureUser(ctx);
    if (!isAdmin(user)) return next();

    const st = getState(ctx.from.id);
    if (!st) return next();

    const text = (ctx.message.text || "").trim();
    if (!text) return next();

    if (st.step === "new_title") {
      // сохранили заголовок, просим тип
      setState(ctx.from.id, { step: "new_type", tempTitle: text });
      await showTypePicker(ctx, "new", "admin_attest_menu");
      return;
    }

    if (st.step === "rename_title") {
      const itemId = st.itemId;
      await pool.query(`UPDATE attestation_items SET title=$2 WHERE id=$1`, [itemId, text]);
      clearState(ctx.from.id);
      await showAdminAttestItem(ctx, itemId);
      return;
    }

    if (st.step === "edit_desc") {
      const itemId = st.itemId;
      await pool.query(`UPDATE attestation_items SET description=$2 WHERE id=$1`, [itemId, text]);
      clearState(ctx.from.id);
      await showAdminAttestItem(ctx, itemId);
      return;
    }

    if (st.step === "await_example") {
      const itemId = st.itemId;
      if (text === "-") {
        await pool.query(
          `UPDATE attestation_items SET example_file_id=NULL, example_file_type=NULL WHERE id=$1`,
          [itemId]
        );
        clearState(ctx.from.id);
        await showAdminAttestItem(ctx, itemId);
        return;
      }
      // если не "-" — игнорируем, пример только файлом
      await ctx.reply("Прикрепи пример файлом (фото/видео), или отправь '-' чтобы убрать.");
      return;
    }

    return next();
  });

  // выбор типа при создании (через callback)
  bot.action(/admin_attest_type_set_new_(normal|photo|video)/, async (ctx) => {
    try {
      await ctx.answerCbQuery().catch(() => {});
      const user = await ensureUser(ctx);
      if (!isAdmin(user)) return;

      const st = getState(ctx.from.id);
      if (!st || st.step !== "new_type") return;

      const t = ctx.match[1] === "normal" ? "normal" : ctx.match[1];
      const title = st.tempTitle;

      // order_index: ставим после текущих максимумов
      const maxRes = await pool.query(`SELECT COALESCE(MAX(order_index),0) AS mx FROM attestation_items`);
      const nextIndex = Number(maxRes.rows[0].mx || 0) + 1;

      const ins = await pool.query(
        `INSERT INTO attestation_items (title, order_index, is_active, is_default, item_type)
         VALUES ($1,$2,TRUE,FALSE,$3)
         RETURNING id`,
        [title, nextIndex, t]
      );
      const itemId = ins.rows[0].id;

      if (t === "photo" || t === "video") {
        // спросить пример
        const kindLabel = t === "video" ? "видео" : "фото";
        setState(ctx.from.id, { step: "await_example", itemId, expected: t });

        const keyboard = Markup.inlineKeyboard([
          [Markup.button.callback("⬅️ Пропустить", `admin_attest_item_${itemId}`)],
        ]);

        await deliver(
          ctx,
          {
            text: `Можешь отправить пример ${kindLabel} (файлом).\nИли нажми «Пропустить».`,
            extra: keyboard,
          },
          { edit: true }
        );
        return;
      }

      clearState(ctx.from.id);
      await showAdminAttestItem(ctx, itemId);
    } catch (err) {
      logError("admin_attest_type_set_new_x", err);
    }
  });

  // перехват showTypePicker для new: подменим callback data
  const originalShowTypePicker = showTypePicker;

  async function showTypePicker(ctx, itemId, backAction) {
    const isNew = itemId === "new";
    const kb = Markup.inlineKeyboard([
      [
        Markup.button.callback(
          "обычный",
          isNew ? `admin_attest_type_set_new_normal` : `admin_attest_type_set_${itemId}_normal`
        ),
        Markup.button.callback(
          "фото",
          isNew ? `admin_attest_type_set_new_photo` : `admin_attest_type_set_${itemId}_photo`
        ),
        Markup.button.callback(
          "видео",
          isNew ? `admin_attest_type_set_new_video` : `admin_attest_type_set_${itemId}_video`
        ),
      ],
      [Markup.button.callback("⬅️ Назад", backAction)],
    ]);

    await deliver(ctx, { text: "Выбери тип элемента:", extra: kb }, { edit: true });
  }

  // приём фото/видео как пример
  bot.on(["photo", "video"], async (ctx, next) => {
    const user = await ensureUser(ctx);
    if (!isAdmin(user)) return next();

    const st = getState(ctx.from.id);
    if (!st || st.step !== "await_example") return next();

    const { itemId, expected } = st;

    let fileId = null;
    let fileType = null;

    if (ctx.message.photo && ctx.message.photo.length) {
      if (expected !== "photo") {
        await ctx.reply("Ожидается видео. Отправь видео или '-' чтобы убрать пример.");
        return;
      }
      fileId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
      fileType = "photo";
    }

    if (ctx.message.video) {
      if (expected !== "video") {
        await ctx.reply("Ожидается фото. Отправь фото или '-' чтобы убрать пример.");
        return;
      }
      fileId = ctx.message.video.file_id;
      fileType = "video";
    }

    if (!fileId) return;

    await pool.query(
      `UPDATE attestation_items
       SET example_file_id=$2, example_file_type=$3
       WHERE id=$1`,
      [itemId, fileId, fileType]
    );

    clearState(ctx.from.id);
    await showAdminAttestItem(ctx, itemId);
  });
}

module.exports = registerAttest;
